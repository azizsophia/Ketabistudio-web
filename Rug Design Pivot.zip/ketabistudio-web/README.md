# Ketabi Studio — Personalised Card Maker (Developer Handoff)

## Overview
A white-label, luxury greeting-card **personalisation maker** for Ketabi Studio. A customer:
1. picks a **collection** (visual style),
2. picks a **card** (occasion or "for a loved one"),
3. **personalises** it (name, front word, colourway, inside message, signature, paper, optional photo, optional custom Arabic),
4. enters **delivery** details, and
5. places the order — which generates a **print-ready file** and sends it to a **print-on-demand (POD) API** that prints and **blind-ships** the card directly to the recipient, branded as Ketabi (no printer/Ketabi invoice in the parcel).

The whole point: Ketabi controls the design; the POD partner only prints + ships.

---

## About the design files
The files in `src/` are a **design reference** built in HTML (a self-contained prototype showing the intended look, flow and behaviour). They are **not** meant to be shipped as-is. The task is to **re-implement this design in the Ketabi web codebase** (e.g. Next.js / React) using its existing conventions, then wire it to a real POD API and payment provider.

- `preview/Ketabi-Card-Maker.standalone.html` — open in any browser to interact with the exact intended UX (works offline). Use this as the behavioural source of truth.
- `src/Ketabi Card Maker.dc.html` — the annotated source (markup + a single logic class). All copy, colours, data and render logic live here.

## Fidelity
**High-fidelity.** Colours, typography, spacing, layouts and interactions are final-intent. Recreate pixel-faithfully, then replace the mocked POD/payment calls with real integrations.

---

## The flow (5 steps)
A single-page stepper. Top bar shows: **Collection → Card → Personalise → Deliver → Print**.

### 1. Collection (`styles`)
3-column grid of 6 collection cards, each previewing the same "Eid Mubarak" card in that style. Clicking one sets `styleId` and advances to **Card**.

### 2. Card (`gallery`)
Heading shows the chosen collection. Two labelled sections of card thumbnails (clean fronts), rendered in the chosen collection:
- **Occasions** (7): Eid Mubarak, Nikah, New Baby, Ramadan, Birthday, Thank You, Get Well.
- **For your loved ones** (5): For My Wife, For My Husband, For My Mum, For My Dad, For My Friend.

Clicking a card sets `itemId`, seeds that card's default accent colour + inside message, and advances to **Personalise**. A "← Collections" link returns to step 1.

### 3. Personalise (`maker`)
Two columns:
- **Left — Live preview**: a row of 6 style "pills" (switch collection live), then **Front** and **Inside** card faces (232×327 design units, rendered at scale).
- **Right — controls**:
  - **Recipient name** (text)
  - **Name on the front?** — `Clean front` (default) / `Show "For <name>"`
  - **Custom front text** (optional) — overrides the preset word; accepts Arabic or English; `dir="auto"`. Shows a spelling caution.
  - **Word on front** (occasions with verified Arabic only) — choose a verified word, or "English only"
  - **Colourway** — 5 swatches
  - **Inside message** (textarea, `dir="auto"`, "+ add a du'a" inserts the card's du'a)
  - **Signed** (text)
  - **Paper** — 2 options
  - **Continue to delivery** (gated — see Arabic spell-confirm)

### 4. Deliver (`checkout`)
Recipient shipping form (name, address, city, postcode, country) + an order summary (mini card thumbnail, collection, paper, price, free delivery). Copy reassures **blind/white-label** shipping. "Place order · <price>" advances to **Print**.

### 5. Print / hand-off (`handoff`)
Demonstrates what happens server-side (the customer would NOT see this in production; it's here to document the integration):
- **Print-ready file**: outside spread (back | front) and inside spread (left blank | designed inside), with spec (A6 folded, artboard+bleed, 300 DPI, CMYK, stock).
- **API payload**: example JSON sent to the POD API.
- **Blind-ship confirmation** checklist.

---

## Data model
All data lives as methods on the logic class. Port to typed models.

### Occasion `{ id, group:'occasion', title, color, eyebrow, en, words[], dua, msg }`
`words` = array of verified Arabic `{ ar, translit }`. Per-card default `color`:
| id | title | color |
|----|-------|-------|
| eid | Eid Mubarak | `#1f6b5a` |
| nikah | Nikah | `#a85c63` |
| baby | New Baby | `#5a86a8` |
| ramadan | Ramadan | `#1f3a54` |
| birthday | Birthday | `#b35c3c` |
| thanks | Thank You | `#a07f4a` |
| getwell | Get Well | `#6f8a5c` |

Verified Arabic words in use (do **not** auto-translate; these are vetted): عيد مبارك (Eid Mubarak), عيد سعيد (Eid Saeed), مبارك (Mabrook), رمضان كريم (Ramadan Kareem), رمضان مبارك (Ramadan Mubarak), شكراً (Shukran), شفاء (Shifa).

### Relationship `{ id, group:'relationship', title, color, eyebrow, headlineEn, word:{ar,translit}, sub, dua, msg }`
| id | title | color | word |
|----|-------|-------|------|
| wife | For My Wife | `#a85c63` | سكينة (Sakeenah) |
| husband | For My Husband | `#1f4f54` | الحمد لله (Alhamdulillah) |
| mum | For My Mum | `#6e4257` | أمي (Ummī) |
| dad | For My Dad | `#2f5a40` | أبي (Abī) |
| friend | For My Friend | `#a87a3c` | أخي في الله |

### Collection (style) `{ id, name, tag }`
`arch` The Arch · `field` Colour Field · `wash` Watercolour · `statement` Statement · `textile` Textile · `image` Imagery. Each has a **front** renderer and an **inside** renderer (see "Card rendering").

### Paper `{ id, name, desc, short, price }`
- `mohawk` — 324gsm Mohawk Fine Paper (uncoated) — $14.00
- `gloss` — 330gsm Fedrigoni Gloss (UV varnish) — $13.00

### Colourway swatches
Terracotta `#b35c3c` · Emerald `#1f6b5a` · Deep Teal `#1f4f54` · Aubergine `#5e3a4a` · Brass `#a07f4a`.
(Picking a card seeds the colourway from that card's `color`; the user can override.)

---

## Card rendering (front + inside)
Both faces are drawn on a **232×327** design canvas (A6 portrait ratio) and scaled with `transform: scale(px/232)` for any display size. Each collection has its own front and inside treatment, **all tinted by the active accent colour**:

- **The Arch** — drawn mihrab arch (double keyline) + solid crescent moon; text centred *inside* the arch.
- **Colour Field** — solid accent ground, cream reversed type; inside = accent spine down the binding edge + quatrefoil motif.
- **Watercolour** — soft radial accent "blooms"; inside = painted bloom + leaf-sprig motif.
- **Statement** — accent bands top & foot, bold Cormorant type; inside word + rule.
- **Textile** — all-over geometric motif tiling + centred cartouche.
- **Imagery** — photo area (see Photo slot) with a cream type panel; inside = tinted photo strip + caption rule.

**Front slots**: `eyebrow`, `bigText` (hero — Arabic word or English), `translit`, `line2`, `foot` (`For <name>` when "show name" is on, else the card's subtitle).

**Type**: Cormorant Garamond (serif display/italics), Reem Kufi (Arabic display), Amiri (Arabic body / RTL messages), Jost (UI labels/eyebrows, uppercase + wide letter-spacing). Base page bg `#ebe6da`; ink `#262320`; card paper `#f4f0e7`/`#f8f2e8`; muted `#6f6657`/`#9a8f7c`; gold `#a07f4a`.

---

## Interactions & behaviour
- **Step nav** via the data flow above; back-links between steps.
- **Live style switch** in the maker re-renders both faces instantly in the new collection (keeping all content + colourway).
- **Clean front vs. name on front** toggles whether `For <name>` appears on the front.
- **+ add a du'a** appends the card's `dua` to the inside message.
- **RTL**: any field containing Arabic (`/[\u0600-\u06FF]/`) renders right-to-left; inside Arabic messages switch to Amiri.

### Arabic spell-confirm (gate) — REQUIRED
When **custom front text contains Arabic**, a confirmation checkbox appears ("I confirm the Arabic I entered is spelled correctly. It will be printed exactly as shown.") and **"Continue to delivery" is disabled until it is ticked**. This prevents misspelled customer Arabic going to print on the customer's own input. Preserve this guard.

### Low-res photo guard (Imagery) — REQUIRED
The Imagery collection shows an advisory: use a photo **≥1500px on the shortest side**; lower-res uploads must be flagged. In production, **reject/​warn at upload time** by reading the image's natural dimensions before accepting it (target ≥1500px short edge for a crisp A6 print at 300 DPI).

### Photo slot
The Imagery front embeds a drag-and-drop image placeholder (`<image-slot>` in the prototype; `src/image-slot.js`). In production use the app's uploader; persist the asset and composite it into the print file's image area. The slot is `232×192` design units at the top of the card.

---

## State management
Single component state object. Key fields: `step`, `styleId`, `itemId`, `recipient`, `sender`, `message`, `accent`, `arabicIndex`, `arabicOff`, `showName`, `customFront`, `arabicOk` (spell-confirm), `paper`, and `ship*` (name/line/city/post/country). Port to your store/router (each `step` could be a route).

---

## POD / print integration (the important part)
**Product**: A6 **folded** greeting card with a **full-colour printed inside** (choose a POD product whose inside is printable — both **Prodigi** and **Gelato** offer this; some cheaper cards print outside-only — avoid those).

**Recommended**: **Prodigi Print API** (or Gelato) — both support a programmatic order API, **white-label / blind** shipping, and **ship-to-recipient**. Stock target: 324gsm Mohawk (uncoated) or 330gsm Fedrigoni gloss; Gelato alternative ~350gsm.

**Print file spec** (generate server-side per order):
- Format: A6 folded, 105 × 148 mm.
- Artboard incl. bleed: 216 × 154 mm (two A6 panels side-by-side + bleed).
- Resolution: 2551 × 1819 px @ **300 DPI**.
- Colour: **CMYK**.
- Two assets per order: **`outside`** (back | front) and **`inside`** (left | message+signature).
- **Render Arabic as outlined/vector text** (not live font) so the printer can't substitute or break letter-shaping. Embed fonts or convert to paths.

**Example API payload** (shape shown in the prototype's hand-off step — adapt to the chosen provider):
```json
{
  "sku": "GLOBAL-GRE-FAP-A6",
  "copies": 1,
  "sizing": "fillPrintArea",
  "recipient": { "name": "...", "address": { "line1": "...", "townOrCity": "...", "postalOrZipCode": "...", "countryCode": "GB" } },
  "assets": [
    { "printArea": "outside", "url": "https://assets.ketabi.studio/o/<order>-out.pdf" },
    { "printArea": "inside",  "url": "https://assets.ketabi.studio/o/<order>-in.pdf" }
  ],
  "shippingMethod": "Mail4Me",
  "packingSlip": { "branding": "white-label" },
  "merchantReference": "<order id>"
}
```
**Blind ship**: enable the provider's white-label/no-branding packing slip so the parcel carries no printer or Ketabi invoice — it simply arrives, as a gift, from the customer.

**Still to wire (mocked in the prototype):** real upload + hosting of the generated PDFs, the POD order call + webhook status, payment (Stripe), and the upload-time low-res image rejection.

---

## Files
- `preview/Ketabi-Card-Maker.standalone.html` — self-contained runnable prototype (behavioural source of truth).
- `src/Ketabi Card Maker.dc.html` — annotated source: all markup, copy, data, colours, and render logic.
- `src/support.js` — the prototype runtime (reference only; do not port).
- `src/image-slot.js` — the drag-drop photo placeholder used by the Imagery collection (reference for the photo-slot behaviour).

> Note: `.dc.html` is a prototype format. Read it for **content, data, colours and layout logic**; re-implement the UI in the Ketabi codebase rather than embedding the prototype runtime.
